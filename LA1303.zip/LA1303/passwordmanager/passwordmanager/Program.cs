﻿using System;

namespace PasswordManagerApp
{
    class Program
    {
        static void Main(string[] args)
        {
            PasswordManager passwordManager = new PasswordManager();
            bool isRunning = true;

            DisplayMainMenu();

            while (isRunning)
            {
                try
                {
                    Console.Write("Bitte wählen Sie eine Option: ");
                    string option = Console.ReadLine();

                    switch (option)
                    {
                        case "1":
                            Console.Clear();
                            passwordManager.AddPassword();
                            DisplayMainMenu();
                            break;
                        case "2":
                            Console.Clear();
                            passwordManager.ShowPasswords();
                            DisplayMainMenu();
                            break;
                        case "3":
                            Console.Clear();
                            passwordManager.DeletePassword();
                            DisplayMainMenu();
                            break;
                        case "4":
                            isRunning = false;
                            break;
                        default:
                            throw new ArgumentException("Ungültige Eingabe, bitte versuchen Sie es erneut.");
                    }
                }
                catch (Exception ex)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Ein Fehler ist aufgetreten: {ex.Message}");
                    Console.ResetColor();
                    DisplayMainMenu();
                }
            }
        }

        static void DisplayMainMenu()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("#########");
            Console.WriteLine("Hauptmenü");
            Console.WriteLine("#########");
            Console.WriteLine();
            Console.ResetColor();
            Console.WriteLine("[1] Passwort hinzufügen");
            Console.WriteLine("[2] Passwörter anzeigen");
            Console.WriteLine("[3] Passwort löschen");
            Console.WriteLine("[4] Exit");
            Console.WriteLine();
            Console.Write("Bitte wählen Sie eine Option: ");
        }

    }
}
