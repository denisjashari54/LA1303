﻿using System;
using System.Linq;

namespace PasswordManagerApp
{
    class PasswordManager
    {
        public void AddPassword()
        {
            try
            {
                var encryptionService = new EncryptionService();
                string password = GetPasswordFromUser(encryptionService);
                string url = GetUrlFromUser();

                var passwordEntry = new PasswordEntry(url, encryptionService.Encrypt(password));

                using (var db = new AppDbContext())
                {
                    db.AddPasswordEntry(passwordEntry);
                }

                Console.WriteLine($"Passwort mit URL '{url}' hinzugefügt.");
                Console.WriteLine("Drücken Sie eine beliebige Taste, um zum Hauptmenü zurückzukehren...");
                Console.ReadKey();
                Console.Clear();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Fehler beim Hinzufügen des Passworts: {ex.Message}");
                Console.ResetColor();
                Console.WriteLine();
            }
        }


        public void ShowPasswords()
        {
            var encryptionService = new EncryptionService();

            using (var db = new AppDbContext())
            {
                Console.Clear(); 
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Passwortliste:");
                Console.WriteLine("--------------");
                Console.ResetColor();
                Console.WriteLine();

                foreach (var entry in db.PasswordEntries)
                {
                    string decryptedPassword = encryptionService.Decrypt(entry.EncryptedPassword);
                    Console.WriteLine($"ID: {entry.Id}, URL: {entry.Url}, Passwort: {decryptedPassword}");
                }
            }

            Console.WriteLine();
            Console.WriteLine("Drücken Sie eine beliebige Taste, um zum Hauptmenü zurückzukehren...");
            Console.ReadKey();
            Console.Clear();
        }

        public void DeletePassword()
        {
            Console.Write("Geben Sie die ID des Passworts ein, das Sie löschen möchten: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                using (var db = new AppDbContext())
                {
                    var entry = db.PasswordEntries.FirstOrDefault(e => e.Id == id);
                    if (entry != null)
                    {
                        db.PasswordEntries.Remove(entry);
                        db.SaveChanges();
                        Console.WriteLine("Passwort gelöscht.");
                    }
                    else
                    {
                        Console.WriteLine("Kein Passwort mit dieser ID gefunden.");
                        Console.WriteLine();
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ungültige Eingabe.");
                Console.ResetColor();
                Console.WriteLine();
            }

            Console.WriteLine("Drücken Sie eine beliebige Taste, um fortzufahren...");
            Console.ReadKey();
            Console.Clear(); 
        }


        private string GetPasswordFromUser(EncryptionService encryptionService)
        {
            while (true)
            {
                Console.WriteLine("Möchten Sie ein eigenes Passwort eingeben oder ein verschlüsseltes Passwort verwenden?");
                Console.WriteLine("[1] Eigenes Passwort eingeben");
                Console.WriteLine("[2] Verschlüsseltes Passwort generieren lassen");

                Console.Write("Bitte wählen Sie eine Option: ");
                string option = Console.ReadLine();

                if (option == "1")
                {
                    Console.Write("Geben Sie das Passwort ein, das Sie hinzufügen möchten: ");
                    string password = Console.ReadLine();
                    return password;
                }
                else if (option == "2")
                {
                    string randomPassword = encryptionService.GenerateRandomPassword();
                    Console.WriteLine($"Automatisch generiertes Passwort: {randomPassword}");
                    return randomPassword;
                }
                else
                {
                    Console.Clear(); 
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Ungültige Option. Bitte wählen Sie eine der verfügbaren Optionen.");
                    Console.ResetColor();
                    Console.WriteLine();
                }
            }
        }
        private string GetUrlFromUser()
        {
            string url = "";
            while (true)
            {
                Console.Write("Geben Sie die URL der Website ein (muss mit www. starten und mit .ch, .de, .net, .com enden): ");
                int cursorLeft = Console.CursorLeft;
                int cursorTop = Console.CursorTop;

                url = Console.ReadLine();

                if (url.StartsWith("www.") && (url.EndsWith(".ch") || url.EndsWith(".de") || url.EndsWith(".net") || url.EndsWith(".com")))
                {
                    return url;
                }

                Console.SetCursorPosition(cursorLeft, cursorTop);
                for (int i = 0; i < url.Length; i++)
                {
                    Console.Write(" ");
                }
                Console.SetCursorPosition(cursorLeft, cursorTop);

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ungültige URL!.");
                Console.ResetColor();
            }
        }

    }
}
