﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

public class AppDbContext : IDisposable
{
    private const string DataFilePath = "passwords.json";
    public List<PasswordEntry> PasswordEntries { get; private set; }

    public AppDbContext()
    {
        PasswordEntries = LoadData();
    }

    private List<PasswordEntry> LoadData()
    {
        if (File.Exists(DataFilePath))
        {
            string json = File.ReadAllText(DataFilePath);
            var entries = JsonSerializer.Deserialize<List<PasswordEntry>>(json);
            return entries ?? new List<PasswordEntry>();
        }
        else
        {
            return new List<PasswordEntry>();
        }
    }

    public void AddPasswordEntry(PasswordEntry entry)
    {
        entry.Id = PasswordEntries.Any() ? PasswordEntries.Max(e => e.Id) + 1 : 1;
        PasswordEntries.Add(entry);
        SaveChanges();
    }

    public void SaveChanges()
    {
        string json = JsonSerializer.Serialize(PasswordEntries, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(DataFilePath, json);
    }

    public void Dispose()
    {

    }
}

public class PasswordEntry
{
    public int Id { get; set; }
    public string Url { get; set; }
    public string EncryptedPassword { get; set; }

    public PasswordEntry() { }

    public PasswordEntry(string url, string encryptedPassword)
    {
        Url = url;
        EncryptedPassword = encryptedPassword;
    }
}
